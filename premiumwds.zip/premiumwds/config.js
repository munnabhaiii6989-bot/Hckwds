'use strict';
// premiumWds settings. Most things can be changed with environment variables.
const path = require('node:path');
const env = process.env;

const dataDir = env.DATA_DIR || path.join(__dirname, 'data');

const contactLinks = [
  { label: 'Discord', value: env.CONTACT_DISCORD },
  { label: 'Telegram', value: env.CONTACT_TELEGRAM },
  { label: 'WhatsApp', value: env.CONTACT_WHATSAPP },
  { label: 'Email', value: env.CONTACT_EMAIL },
].filter((c) => c.value);

module.exports = {
  siteName: 'premiumWds',
  port: Number(env.PORT) || 3000,
  dataDir,
  uploadDir: path.join(dataDir, 'uploads'),

  // The account that registers with this email becomes the site owner/admin.
  adminEmail: (env.ADMIN_EMAIL || '').trim().toLowerCase(),

  // Set COOKIE_SECURE=1 when the site runs on https (it should).
  secureCookies: env.COOKIE_SECURE === '1',
  // Set TRUST_PROXY=1 when running behind a host/proxy that sets X-Forwarded-For.
  trustProxy: env.TRUST_PROXY === '1',

  maxUploadMB: Number(env.MAX_UPLOAD_MB) || 25,
  allowedExt: ['.jar', '.zip', '.mcpack', '.mcaddon', '.litemod', '.7z', '.json', '.txt', '.md'],
  // These must really be zip archives (they start with the "PK" signature).
  zipExt: ['.jar', '.zip', '.mcpack', '.mcaddon', '.litemod'],
  categories: ['Hacked client', 'Mod / utility', 'Config / script', 'Resource pack', 'Other'],

  planDays: 30,
  plans: {
    free: {
      id: 'free',
      name: 'Free',
      price: 0,
      uploadsPerMonth: 0, // 0 = cannot upload
      canReview: false,
      canContact: false,
    },
    basic: {
      id: 'basic',
      name: 'Basic',
      price: 1.22,
      uploadsPerMonth: 5,
      canReview: true,
      canContact: false,
    },
    premium: {
      id: 'premium',
      name: 'Premium',
      price: Number(env.PREMIUM_PRICE) || 4.99,
      uploadsPerMonth: null, // null = unlimited
      canReview: true,
      canContact: true,
    },
  },

  // Shown on the upgrade page. Put your bKash / PayPal / crypto details here.
  paymentInfo:
    env.PAYMENT_INFO ||
    'The owner has not added payment details yet. Set the PAYMENT_INFO environment variable.',
  contactLinks,
};
