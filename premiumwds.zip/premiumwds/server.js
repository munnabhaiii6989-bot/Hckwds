'use strict';
// premiumWds server. No npm packages needed: Node 22.13+ only.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

const PUBLIC_DIR = path.join(__dirname, 'public');
const DAY = 24 * 60 * 60 * 1000;
const MAX_BYTES = config.maxUploadMB * 1024 * 1024;

fs.mkdirSync(config.uploadDir, { recursive: true });
const db = new DatabaseSync(path.join(config.dataDir, 'premiumwds.db'));
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  plan_expires INTEGER,
  is_admin INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  mc_version TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL,
  orig_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  downloads INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  UNIQUE (file_id, user_id)
);
CREATE TABLE IF NOT EXISTS upload_usage (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, month)
);
CREATE TABLE IF NOT EXISTS upgrade_requests (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL,
  reference TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at INTEGER NOT NULL
);
`);

if (config.adminEmail) {
  db.prepare('UPDATE users SET is_admin = 1 WHERE email = ?').run(config.adminEmail);
}

// ---------- helpers ----------
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const now = () => Date.now();
const monthKey = () => new Date().toISOString().slice(0, 7); // UTC calendar month, e.g. 2026-11
const sha = (v) => crypto.createHash('sha256').update(v).digest('hex');

function text(value, label, min, max) {
  const v = typeof value === 'string' ? value.trim() : '';
  if (v.length < min) throw new HttpError(400, `${label} is too short.`);
  if (v.length > max) throw new HttpError(400, `${label} is too long (max ${max} characters).`);
  return v;
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}
const DUMMY_SALT = crypto.randomBytes(16).toString('hex');

function checkPassword(user, password) {
  const salt = user ? user.pass_salt : DUMMY_SALT;
  const got = Buffer.from(hashPassword(password, salt), 'hex');
  if (!user) return false;
  const want = Buffer.from(user.pass_hash, 'hex');
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}

// plan that currently applies (an expired paid plan counts as free)
function effectivePlan(user) {
  if (user.is_admin) return config.plans.premium; // the owner can always do everything
  if (user.plan !== 'free' && user.plan_expires && user.plan_expires < now()) return config.plans.free;
  return config.plans[user.plan] || config.plans.free;
}
function usageThisMonth(userId) {
  const row = db.prepare('SELECT count FROM upload_usage WHERE user_id = ? AND month = ?').get(userId, monthKey());
  return row ? row.count : 0;
}
function publicPlan(p) {
  return {
    id: p.id,
    name: p.name,
    price: p.price,
    uploadsPerMonth: p.uploadsPerMonth,
    canReview: p.canReview,
    canContact: p.canContact,
  };
}
function publicUser(u) {
  const plan = effectivePlan(u);
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    isAdmin: !!u.is_admin,
    plan: plan.id,
    planExpires: plan.id === 'free' ? null : u.plan_expires,
  };
}

// ---------- rate limiting (in memory) ----------
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const t = now();
  const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
  if (arr.length >= max) throw new HttpError(429, 'Too many attempts. Please wait a bit and try again.');
  arr.push(t);
  hits.set(key, arr);
}
setInterval(() => {
  const t = now();
  for (const [k, arr] of hits) if (!arr.some((x) => t - x < 3600 * 1000)) hits.delete(k);
  db.prepare('DELETE FROM sessions WHERE expires < ?').run(t);
}, 10 * 60 * 1000).unref();

function clientIp(req) {
  if (config.trustProxy) {
    const xf = req.headers['x-forwarded-for'];
    if (xf) return String(xf).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

// ---------- sessions ----------
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}
function cookieHeader(value, maxAgeSec) {
  return `sid=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${config.secureCookies ? '; Secure' : ''}`;
}
function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires) VALUES (?, ?, ?)').run(sha(token), userId, now() + 30 * DAY);
  res.setHeader('Set-Cookie', cookieHeader(token, 30 * 24 * 3600));
}
function currentUser(req) {
  const token = parseCookies(req).sid;
  if (!token) return null;
  return (
    db
      .prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires > ?')
      .get(sha(token), now()) || null
  );
}
function requireUser(ctx) {
  if (!ctx.user) throw new HttpError(401, 'Please log in first.');
  return ctx.user;
}
function requireAdmin(ctx) {
  const u = requireUser(ctx);
  if (!u.is_admin) throw new HttpError(403, 'Admins only.');
  return u;
}

// ---------- request bodies ----------
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const tooLarge = () => new HttpError(413, `File is too large. The limit is ${config.maxUploadMB} MB.`);
    // Oversized bodies are read and thrown away (up to a hard cap) so the browser can
    // finish sending and actually receive the "too large" message instead of a network error.
    const DRAIN_CAP = limit + 100 * 1024 * 1024;
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limit) {
      if (declared > DRAIN_CAP) req.destroy();
      else req.resume();
      return reject(tooLarge());
    }
    const chunks = [];
    let size = 0;
    let failed = false;
    req.on('data', (c) => {
      size += c.length;
      if (failed) {
        if (size > DRAIN_CAP) req.destroy();
        return;
      }
      if (size > limit) {
        failed = true;
        chunks.length = 0;
        reject(tooLarge());
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => !failed && resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req) {
  const buf = await readBody(req, 64 * 1024);
  try {
    const v = JSON.parse(buf.toString('utf8') || '{}');
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch {
    /* fall through */
  }
  throw new HttpError(400, 'Invalid request.');
}

// Minimal multipart/form-data parser (text fields + one file).
function parseMultipart(buf, contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!m) throw new HttpError(400, 'Expected a file upload.');
  const boundary = Buffer.from('--' + (m[1] || m[2]).trim());
  const sep = Buffer.concat([Buffer.from('\r\n'), boundary]);
  const fields = {};
  let file = null;
  let pos = buf.indexOf(boundary);
  while (pos !== -1) {
    pos += boundary.length;
    if (buf[pos] === 0x2d && buf[pos + 1] === 0x2d) break; // closing boundary
    pos += 2; // CRLF after boundary
    const headerEnd = buf.indexOf('\r\n\r\n', pos);
    if (headerEnd === -1) break;
    const headers = buf.subarray(pos, headerEnd).toString('utf8');
    const start = headerEnd + 4;
    const next = buf.indexOf(sep, start);
    if (next === -1) break;
    const content = buf.subarray(start, next);
    const name = /name="([^"]*)"/i.exec(headers);
    const filename = /filename="([^"]*)"/i.exec(headers);
    if (name) {
      if (filename) {
        if (name[1] === 'file' && !file) file = { filename: filename[1], data: content };
      } else if (content.length < 10000) {
        fields[name[1]] = content.toString('utf8');
      }
    }
    pos = next + 2; // start of next boundary
  }
  return { fields, file };
}

function cleanFilename(name) {
  const base = path.basename(String(name).replace(/\\/g, '/')).replace(/[\x00-\x1f\x7f]/g, '');
  return base.slice(-120) || 'file';
}

// ---------- API routes ----------
const routes = [];
function route(method, pattern, handler) {
  routes.push({ method, re: new RegExp('^' + pattern + '$'), handler });
}
function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(data);
}

route('GET', '/api/config', (ctx) => ({
  siteName: config.siteName,
  plans: Object.values(config.plans).map(publicPlan),
  categories: config.categories,
  maxUploadMB: config.maxUploadMB,
  allowedExt: config.allowedExt,
  planDays: config.planDays,
  paymentInfo: config.paymentInfo,
}));

route('POST', '/api/register', async (ctx) => {
  rateLimit('reg:' + ctx.ip, 10, 3600 * 1000);
  const b = await readJson(ctx.req);
  const name = text(b.name, 'Name', 2, 40);
  const email = text(b.email, 'Email', 5, 120).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, 'Enter a valid email address.');
  const password = typeof b.password === 'string' ? b.password : '';
  if (password.length < 8 || password.length > 128) throw new HttpError(400, 'Password must be 8 to 128 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw new HttpError(409, 'That email is already registered.');
  const salt = crypto.randomBytes(16).toString('hex');
  const info = db
    .prepare('INSERT INTO users (email, name, pass_salt, pass_hash, is_admin, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(email, name, salt, hashPassword(password, salt), email === config.adminEmail ? 1 : 0, now());
  startSession(ctx.res, Number(info.lastInsertRowid));
  return { ok: true };
});

route('POST', '/api/login', async (ctx) => {
  rateLimit('login:' + ctx.ip, 15, 15 * 60 * 1000);
  const b = await readJson(ctx.req);
  const email = typeof b.email === 'string' ? b.email.trim().toLowerCase() : '';
  const password = typeof b.password === 'string' ? b.password.slice(0, 128) : '';
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!checkPassword(user, password)) throw new HttpError(401, 'Wrong email or password.');
  startSession(ctx.res, user.id);
  return { ok: true };
});

route('POST', '/api/logout', (ctx) => {
  const token = parseCookies(ctx.req).sid;
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(token));
  ctx.res.setHeader('Set-Cookie', cookieHeader('', 0));
  return { ok: true };
});

route('GET', '/api/me', (ctx) => {
  if (!ctx.user) return { user: null };
  const plan = effectivePlan(ctx.user);
  return {
    user: publicUser(ctx.user),
    plan: publicPlan(plan),
    usage: { used: usageThisMonth(ctx.user.id), limit: plan.uploadsPerMonth, month: monthKey() },
    upgrades: db
      .prepare('SELECT id, plan, reference, status, created_at FROM upgrade_requests WHERE user_id = ? ORDER BY id DESC LIMIT 10')
      .all(ctx.user.id),
  };
});

const FILE_COLS = `f.id, f.title, f.description, f.mc_version, f.category, f.orig_name, f.size, f.status, f.downloads,
  f.created_at, f.user_id, u.name AS author,
  (SELECT AVG(rating) FROM reviews r WHERE r.file_id = f.id) AS rating,
  (SELECT COUNT(*) FROM reviews r WHERE r.file_id = f.id) AS review_count`;

route('GET', '/api/files', (ctx) => {
  const q = (ctx.url.searchParams.get('q') || '').trim().slice(0, 60);
  const cat = ctx.url.searchParams.get('category') || '';
  const where = ["f.status = 'approved'"];
  const params = [];
  if (q) {
    const like = '%' + q.replace(/[\\%_]/g, (c) => '\\' + c) + '%';
    where.push("(f.title LIKE ? ESCAPE '\\' OR f.description LIKE ? ESCAPE '\\' OR f.mc_version LIKE ? ESCAPE '\\')");
    params.push(like, like, like);
  }
  if (config.categories.includes(cat)) {
    where.push('f.category = ?');
    params.push(cat);
  }
  const files = db
    .prepare(`SELECT ${FILE_COLS} FROM files f JOIN users u ON u.id = f.user_id WHERE ${where.join(' AND ')} ORDER BY f.id DESC LIMIT 100`)
    .all(...params);
  return { files };
});

route('GET', '/api/my/files', (ctx) => {
  const u = requireUser(ctx);
  return {
    files: db.prepare(`SELECT ${FILE_COLS} FROM files f JOIN users u ON u.id = f.user_id WHERE f.user_id = ? ORDER BY f.id DESC`).all(u.id),
  };
});

function loadVisibleFile(ctx, id) {
  const f = db.prepare(`SELECT ${FILE_COLS}, f.stored_name FROM files f JOIN users u ON u.id = f.user_id WHERE f.id = ?`).get(id);
  const u = ctx.user;
  if (!f || (f.status !== 'approved' && !(u && (u.is_admin || u.id === f.user_id)))) throw new HttpError(404, 'File not found.');
  return f;
}

route('GET', '/api/files/(\\d+)', (ctx, id) => {
  const f = loadVisibleFile(ctx, Number(id));
  delete f.stored_name;
  const reviews = db
    .prepare('SELECT r.id, r.rating, r.body, r.created_at, r.user_id, u.name AS author FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.file_id = ? ORDER BY r.id DESC LIMIT 100')
    .all(f.id);
  return { file: f, reviews };
});

route('GET', '/api/files/(\\d+)/download', (ctx, id) => {
  const u = requireUser(ctx);
  const f = loadVisibleFile(ctx, Number(id));
  const full = path.join(config.uploadDir, f.stored_name);
  let stat;
  try {
    stat = fs.statSync(full);
  } catch {
    throw new HttpError(404, 'File is missing on the server.');
  }
  if (f.status === 'approved' && f.user_id !== u.id) {
    db.prepare('UPDATE files SET downloads = downloads + 1 WHERE id = ?').run(f.id);
  }
  const ascii = f.orig_name.replace(/[^\w.\- ]/g, '_');
  ctx.res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Length': stat.size,
    'Content-Disposition': `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(f.orig_name)}`,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'private, no-store',
  });
  const stream = fs.createReadStream(full);
  stream.on('error', () => ctx.res.destroy());
  stream.pipe(ctx.res);
  return undefined; // response already handled
});

route('POST', '/api/files', async (ctx) => {
  const user = requireUser(ctx);
  const plan = effectivePlan(user);
  const limit = plan.uploadsPerMonth;
  if (limit === 0) throw new HttpError(403, 'Uploading needs a Basic or Premium plan.');
  const overLimit = () =>
    limit !== null && usageThisMonth(user.id) >= limit
      ? new HttpError(403, `You have used all ${limit} uploads for this month. Upgrade to Premium for unlimited uploads.`)
      : null;
  if (overLimit()) throw overLimit(); // cheap early check, before reading the file

  const body = await readBody(ctx.req, MAX_BYTES + 256 * 1024);
  const { fields, file } = parseMultipart(body, ctx.req.headers['content-type']);
  if (!file || !file.data.length) throw new HttpError(400, 'Choose a file to upload.');
  if (fields.agree !== 'yes') throw new HttpError(400, 'You must confirm the upload rules.');
  const title = text(fields.title, 'Title', 3, 80);
  const description = text(fields.description || '', 'Description', 0, 2000);
  const mcVersion = text(fields.mc_version || '', 'Minecraft version', 0, 20);
  if (!config.categories.includes(fields.category)) throw new HttpError(400, 'Pick a category.');

  const origName = cleanFilename(file.filename);
  const ext = path.extname(origName).toLowerCase();
  if (!config.allowedExt.includes(ext)) throw new HttpError(400, `This file type is not allowed. Allowed: ${config.allowedExt.join(' ')}`);
  if (file.data.length > MAX_BYTES) throw new HttpError(413, `File is too large. The limit is ${config.maxUploadMB} MB.`);
  if (config.zipExt.includes(ext) && !(file.data[0] === 0x50 && file.data[1] === 0x4b)) {
    throw new HttpError(400, `That ${ext} file is not a valid archive.`);
  }

  // Check again and insert in the same synchronous step so parallel uploads cannot slip past the limit.
  if (overLimit()) throw overLimit();
  const stored = crypto.randomBytes(16).toString('hex') + ext;
  fs.writeFileSync(path.join(config.uploadDir, stored), file.data, { mode: 0o640 });
  const status = user.is_admin ? 'approved' : 'pending';
  const info = db
    .prepare('INSERT INTO files (user_id, title, description, mc_version, category, orig_name, stored_name, size, sha256, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(user.id, title, description, mcVersion, fields.category, origName, stored, file.data.length, sha(file.data), status, now());
  db.prepare('INSERT INTO upload_usage (user_id, month, count) VALUES (?, ?, 1) ON CONFLICT (user_id, month) DO UPDATE SET count = count + 1').run(user.id, monthKey());
  return { ok: true, id: Number(info.lastInsertRowid), status };
});

route('DELETE', '/api/files/(\\d+)', (ctx, id) => {
  const user = requireUser(ctx);
  const f = db.prepare('SELECT id, user_id, stored_name FROM files WHERE id = ?').get(Number(id));
  if (!f || (f.user_id !== user.id && !user.is_admin)) throw new HttpError(404, 'File not found.');
  db.prepare('DELETE FROM files WHERE id = ?').run(f.id);
  fs.rm(path.join(config.uploadDir, f.stored_name), { force: true }, () => {});
  return { ok: true };
});

route('POST', '/api/files/(\\d+)/reviews', async (ctx, id) => {
  const user = requireUser(ctx);
  if (!effectivePlan(user).canReview) throw new HttpError(403, 'Writing reviews needs a Basic or Premium plan.');
  const b = await readJson(ctx.req);
  const f = db.prepare("SELECT id, user_id FROM files WHERE id = ? AND status = 'approved'").get(Number(id));
  if (!f) throw new HttpError(404, 'File not found.');
  if (f.user_id === user.id) throw new HttpError(400, 'You cannot review your own file.');
  const rating = Number(b.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new HttpError(400, 'Choose a rating from 1 to 5.');
  const body = text(b.body || '', 'Review', 0, 1000);
  db.prepare('INSERT INTO reviews (file_id, user_id, rating, body, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT (file_id, user_id) DO UPDATE SET rating = excluded.rating, body = excluded.body, created_at = excluded.created_at').run(f.id, user.id, rating, body, now());
  return { ok: true };
});

route('DELETE', '/api/reviews/(\\d+)', (ctx, id) => {
  const user = requireUser(ctx);
  const r = db.prepare('SELECT id, user_id FROM reviews WHERE id = ?').get(Number(id));
  if (!r || (r.user_id !== user.id && !user.is_admin)) throw new HttpError(404, 'Review not found.');
  db.prepare('DELETE FROM reviews WHERE id = ?').run(r.id);
  return { ok: true };
});

route('POST', '/api/upgrade', async (ctx) => {
  const user = requireUser(ctx);
  const b = await readJson(ctx.req);
  if (b.plan !== 'basic' && b.plan !== 'premium') throw new HttpError(400, 'Pick a plan.');
  const reference = text(b.reference, 'Payment reference', 3, 120);
  const note = text(b.note || '', 'Note', 0, 500);
  if (db.prepare("SELECT 1 FROM upgrade_requests WHERE user_id = ? AND status = 'pending'").get(user.id)) {
    throw new HttpError(409, 'You already have a request waiting for the owner to confirm.');
  }
  db.prepare('INSERT INTO upgrade_requests (user_id, plan, reference, note, created_at) VALUES (?, ?, ?, ?, ?)').run(user.id, b.plan, reference, note, now());
  return { ok: true };
});

route('GET', '/api/contact', (ctx) => {
  const user = requireUser(ctx);
  if (!effectivePlan(user).canContact) throw new HttpError(403, 'Direct contact is a Premium feature.');
  return { links: config.contactLinks };
});

route('POST', '/api/contact', async (ctx) => {
  const user = requireUser(ctx);
  if (!effectivePlan(user).canContact) throw new HttpError(403, 'Direct contact is a Premium feature.');
  rateLimit('msg:' + user.id, 10, 3600 * 1000);
  const b = await readJson(ctx.req);
  const subject = text(b.subject, 'Subject', 3, 100);
  const body = text(b.body, 'Message', 5, 2000);
  db.prepare('INSERT INTO messages (user_id, subject, body, created_at) VALUES (?, ?, ?, ?)').run(user.id, subject, body, now());
  return { ok: true };
});

// ----- admin -----
route('GET', '/api/admin/overview', (ctx) => {
  requireAdmin(ctx);
  return {
    pendingFiles: db
      .prepare(`SELECT ${FILE_COLS} FROM files f JOIN users u ON u.id = f.user_id WHERE f.status = 'pending' ORDER BY f.id`)
      .all(),
    upgrades: db
      .prepare("SELECT q.id, q.plan, q.reference, q.note, q.created_at, u.name, u.email FROM upgrade_requests q JOIN users u ON u.id = q.user_id WHERE q.status = 'pending' ORDER BY q.id")
      .all(),
    messages: db
      .prepare("SELECT m.id, m.subject, m.body, m.created_at, u.name, u.email FROM messages m JOIN users u ON u.id = m.user_id WHERE m.status = 'open' ORDER BY m.id")
      .all(),
    users: db.prepare('SELECT id, name, email, plan, plan_expires, is_admin, created_at FROM users ORDER BY id DESC LIMIT 200').all(),
    stats: {
      users: db.prepare('SELECT COUNT(*) AS n FROM users').get().n,
      files: db.prepare("SELECT COUNT(*) AS n FROM files WHERE status = 'approved'").get().n,
    },
  };
});

route('POST', '/api/admin/files/(\\d+)/status', async (ctx, id) => {
  requireAdmin(ctx);
  const b = await readJson(ctx.req);
  if (b.status !== 'approved' && b.status !== 'rejected') throw new HttpError(400, 'Invalid status.');
  const r = db.prepare('UPDATE files SET status = ? WHERE id = ?').run(b.status, Number(id));
  if (!r.changes) throw new HttpError(404, 'File not found.');
  return { ok: true };
});

function grantPlan(userId, planId, days) {
  const u = db.prepare('SELECT plan, plan_expires FROM users WHERE id = ?').get(userId);
  if (!u) throw new HttpError(404, 'User not found.');
  if (planId === 'free') {
    db.prepare("UPDATE users SET plan = 'free', plan_expires = NULL WHERE id = ?").run(userId);
    return;
  }
  const stillActive = u.plan === planId && u.plan_expires && u.plan_expires > now();
  const base = stillActive ? u.plan_expires : now();
  db.prepare('UPDATE users SET plan = ?, plan_expires = ? WHERE id = ?').run(planId, base + days * DAY, userId);
}

route('POST', '/api/admin/upgrades/(\\d+)', async (ctx, id) => {
  requireAdmin(ctx);
  const b = await readJson(ctx.req);
  const q = db.prepare("SELECT * FROM upgrade_requests WHERE id = ? AND status = 'pending'").get(Number(id));
  if (!q) throw new HttpError(404, 'Request not found.');
  if (b.action === 'approve') {
    grantPlan(q.user_id, q.plan, config.planDays);
    db.prepare("UPDATE upgrade_requests SET status = 'approved' WHERE id = ?").run(q.id);
  } else if (b.action === 'reject') {
    db.prepare("UPDATE upgrade_requests SET status = 'rejected' WHERE id = ?").run(q.id);
  } else {
    throw new HttpError(400, 'Invalid action.');
  }
  return { ok: true };
});

route('POST', '/api/admin/users/(\\d+)/plan', async (ctx, id) => {
  requireAdmin(ctx);
  const b = await readJson(ctx.req);
  if (!config.plans[b.plan]) throw new HttpError(400, 'Invalid plan.');
  const days = Math.min(Math.max(parseInt(b.days, 10) || config.planDays, 1), 3650);
  grantPlan(Number(id), b.plan, days);
  return { ok: true };
});

route('POST', '/api/admin/messages/(\\d+)/done', (ctx, id) => {
  requireAdmin(ctx);
  db.prepare("UPDATE messages SET status = 'done' WHERE id = ?").run(Number(id));
  return { ok: true };
});

// ---------- static files ----------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};
function serveStatic(req, res, pathname) {
  let rel;
  try {
    rel = decodeURIComponent(pathname);
  } catch {
    throw new HttpError(400, 'Bad request.');
  }
  if (rel.includes('\0')) throw new HttpError(400, 'Bad request.');
  if (rel === '/') rel = '/index.html';
  const full = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!full.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(403, 'Forbidden.');
  let stat;
  try {
    stat = fs.statSync(full);
  } catch {
    throw new HttpError(404, 'Not found.');
  }
  if (!stat.isFile()) throw new HttpError(404, 'Not found.');
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
    'Content-Length': stat.size,
    'Cache-Control': 'no-cache',
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(full).pipe(res);
}

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  );
  try {
    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;
    if (!pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed.');
      return serveStatic(req, res, pathname);
    }
    if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'fetch') throw new HttpError(403, 'Blocked request.');
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(pathname);
      if (!m) continue;
      const ctx = { req, res, url, ip: clientIp(req), user: currentUser(req) };
      const out = await r.handler(ctx, ...m.slice(1));
      if (out !== undefined) json(res, 200, out);
      return;
    }
    throw new HttpError(404, 'Not found.');
  } catch (err) {
    if (res.headersSent) return res.destroy();
    if (err instanceof HttpError) {
      res.writeHead(err.status, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: err.message }));
    }
    console.error(err);
    res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ error: 'Something went wrong on the server.' }));
  }
});

server.listen(config.port, () => {
  console.log(`${config.siteName} is running on http://localhost:${config.port}`);
  if (!config.adminEmail) console.log('Tip: set ADMIN_EMAIL so your account becomes the site owner.');
});
