'use strict';
// End-to-end check of the plan rules. Run with: npm test
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const PORT = 4100 + Math.floor(Math.random() * 500);
const BASE = `http://127.0.0.1:${PORT}`;
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'pwds-'));
let passed = 0;
let failed = 0;

function check(name, cond, extra) {
  if (cond) passed++;
  else {
    failed++;
    console.log('FAIL:', name, extra === undefined ? '' : JSON.stringify(extra));
  }
}

class Client {
  constructor() {
    this.cookie = '';
  }
  async call(method, url, { json, form, headers = {}, csrf = true } = {}) {
    const h = { ...headers };
    if (this.cookie) h.cookie = this.cookie;
    if (csrf) h['x-requested-with'] = 'fetch';
    let body;
    if (json) {
      h['content-type'] = 'application/json';
      body = JSON.stringify(json);
    }
    if (form) body = form;
    const res = await fetch(BASE + url, { method, headers: h, body, redirect: 'manual' });
    const sc = res.headers.get('set-cookie');
    if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    const type = res.headers.get('content-type') || '';
    const data = type.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer());
    return { status: res.status, data, headers: res.headers };
  }
}

const zipLike = (n = 200) => Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.alloc(n, 7)]);
function uploadForm(over = {}) {
  const fd = new FormData();
  fd.append('title', over.title || 'Test client');
  fd.append('category', 'Hacked client');
  fd.append('mc_version', '1.8.9');
  fd.append('description', 'desc');
  fd.append('agree', over.agree || 'yes');
  fd.append('file', new Blob([over.data || zipLike()]), over.name || 'client.jar');
  return fd;
}

async function register(name, email) {
  const c = new Client();
  const r = await c.call('POST', '/api/register', { json: { name, email, password: 'password123' } });
  check('register ' + name, r.status === 200, r.data);
  return c;
}

async function main() {
  const server = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, ADMIN_EMAIL: 'owner@example.com', MAX_UPLOAD_MB: '1', CONTACT_DISCORD: 'owner#0001' },
    stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((resolve, reject) => {
    server.stdout.on('data', (d) => String(d).includes('running') && resolve());
    server.on('exit', () => reject(new Error('server exited')));
    setTimeout(() => reject(new Error('server did not start')), 8000);
  });

  try {
    const anon = new Client();

    // static + headers + traversal
    let r = await anon.call('GET', '/');
    check('home page served', r.status === 200 && String(r.data).includes('premium'), r.status);
    check('CSP header present', !!r.headers.get('content-security-policy'));
    for (const p of ['/../server.js', '/%2e%2e/server.js', '/..%2fconfig.js', '/%00']) {
      r = await anon.call('GET', p);
      check('traversal blocked ' + p, r.status === 403 || r.status === 404 || r.status === 400, r.status);
    }
    r = await anon.call('GET', '/api/config');
    const plans = Object.fromEntries(r.data.plans.map((p) => [p.id, p]));
    check('plans: free $0, basic $1.22 / 5 uploads, premium unlimited',
      plans.free.price === 0 && plans.free.uploadsPerMonth === 0 && plans.basic.price === 1.22 && plans.basic.uploadsPerMonth === 5 && plans.premium.uploadsPerMonth === null && plans.premium.canContact === true && plans.basic.canContact === false, plans);

    // CSRF header required
    r = await anon.call('POST', '/api/login', { json: { email: 'a@b.co', password: 'x' }, csrf: false });
    check('POST without header is blocked', r.status === 403, r.status);

    // accounts
    const owner = await register('Owner', 'owner@example.com');
    const free = await register('Free Fred', 'free@example.com');
    const basic = await register('Basic Bea', 'basic@example.com');
    const premium = await register('Premium Pat', 'premium@example.com');
    check('duplicate email rejected', (await anon.call('POST', '/api/register', { json: { name: 'X Y', email: 'free@example.com', password: 'password123' } })).status === 409);
    check('short password rejected', (await anon.call('POST', '/api/register', { json: { name: 'X Y', email: 'n@example.com', password: 'short' } })).status === 400);
    check('wrong password rejected', (await anon.call('POST', '/api/login', { json: { email: 'free@example.com', password: 'nope-nope' } })).status === 401);
    r = await owner.call('GET', '/api/me');
    check('owner is admin', r.data.user.isAdmin === true);
    r = await free.call('GET', '/api/me');
    check('new user is on Free and not admin', r.data.user.plan === 'free' && r.data.user.isAdmin === false);

    // admin gating
    check('non-admin blocked from admin API', (await free.call('GET', '/api/admin/overview')).status === 403);
    check('logged-out blocked from admin API', (await anon.call('GET', '/api/admin/overview')).status === 401);

    // give plans via the owner panel
    const users = (await owner.call('GET', '/api/admin/overview')).data.users;
    const idOf = (email) => users.find((u) => u.email === email).id;
    check('owner sets basic', (await owner.call('POST', `/api/admin/users/${idOf('basic@example.com')}/plan`, { json: { plan: 'basic', days: 30 } })).status === 200);
    check('owner sets premium', (await owner.call('POST', `/api/admin/users/${idOf('premium@example.com')}/plan`, { json: { plan: 'premium', days: 30 } })).status === 200);

    r = await owner.call('POST', '/api/files', { form: uploadForm({ title: 'Owner file' }) });
    check('owner can upload and it is published at once', r.status === 200 && r.data.status === 'approved', r.data);

    // ---- FREE plan ----
    r = await free.call('POST', '/api/files', { form: uploadForm() });
    check('Free cannot upload', r.status === 403, r.data);
    r = await free.call('POST', '/api/contact', { json: { subject: 'Hello', body: 'Hello there' } });
    check('Free cannot contact', r.status === 403, r.data);
    check('Free cannot read contact links', (await free.call('GET', '/api/contact')).status === 403);
    check('Basic cannot contact', (await basic.call('POST', '/api/contact', { json: { subject: 'Hello', body: 'Hello there' } })).status === 403);

    // ---- BASIC plan ----
    r = await basic.call('POST', '/api/files', { form: uploadForm({ name: 'virus.exe' }) });
    check('bad extension rejected', r.status === 400, r.data);
    r = await basic.call('POST', '/api/files', { form: uploadForm({ data: Buffer.from('not a zip at all'), name: 'fake.jar' }) });
    check('fake jar rejected', r.status === 400, r.data);
    r = await basic.call('POST', '/api/files', { form: uploadForm({ agree: 'no' }) });
    check('rules checkbox required', r.status === 400, r.data);
    r = await basic.call('POST', '/api/files', { form: uploadForm({ data: Buffer.concat([zipLike(), Buffer.alloc(2 * 1024 * 1024)]) }) });
    check('oversize rejected (413)', r.status === 413, r.status);
    r = await basic.call('GET', '/api/me');
    check('failed uploads did not use quota', r.data.usage.used === 0 && r.data.usage.limit === 5, r.data.usage);

    const ids = [];
    for (let i = 1; i <= 4; i++) {
      r = await basic.call('POST', '/api/files', { form: uploadForm({ title: 'Basic file ' + i }) });
      check('Basic upload ' + i + ' ok', r.status === 200 && r.data.status === 'pending', r.data);
      ids.push(r.data.id);
    }
    // 3 uploads at the same time with 1 slot left: exactly one may succeed
    const burst = await Promise.all([1, 2, 3].map((i) => basic.call('POST', '/api/files', { form: uploadForm({ title: 'Burst ' + i }) })));
    const okCount = burst.filter((x) => x.status === 200).length;
    check('parallel uploads cannot beat the limit (exactly 1 of 3)', okCount === 1, burst.map((x) => x.status));
    r = await basic.call('POST', '/api/files', { form: uploadForm({ title: 'Sixth' }) });
    check('Basic 6th upload blocked', r.status === 403 && /Premium/.test(r.data.error), r.data);
    r = await basic.call('GET', '/api/me');
    check('usage shows 5 of 5', r.data.usage.used === 5 && r.data.usage.limit === 5, r.data.usage);

    // deleting does not give the quota back
    const mine = (await basic.call('GET', '/api/my/files')).data.files;
    check('delete own file', (await basic.call('DELETE', '/api/files/' + mine[0].id)).status === 200);
    r = await basic.call('POST', '/api/files', { form: uploadForm({ title: 'After delete' }) });
    check('deleting a file does not refund the quota', r.status === 403, r.data);

    // pending files are hidden; admin approves
    const target = ids[0];
    check('pending file hidden from others', (await free.call('GET', '/api/files/' + target)).status === 404);
    check('pending file not in public list', !(await anon.call('GET', '/api/files')).data.files.some((f) => f.id === target));
    check('pending file cannot be downloaded by others', (await free.call('GET', `/api/files/${target}/download`)).status === 404);
    check('Free cannot approve', (await free.call('POST', `/api/admin/files/${target}/status`, { json: { status: 'approved' } })).status === 403);
    check('owner approves', (await owner.call('POST', `/api/admin/files/${target}/status`, { json: { status: 'approved' } })).status === 200);
    r = await anon.call('GET', '/api/files');
    check('approved file is listed', r.data.files.some((f) => f.id === target));

    // downloads
    check('download needs login', (await anon.call('GET', `/api/files/${target}/download`)).status === 401);
    r = await free.call('GET', `/api/files/${target}/download`);
    check('Free can download approved file', r.status === 200 && Buffer.isBuffer(r.data) && r.data[0] === 0x50 && /attachment/.test(r.headers.get('content-disposition')) && r.headers.get('x-content-type-options') === 'nosniff', r.status);
    r = await anon.call('GET', '/api/files/' + target);
    check('download counter went up', r.data.file.downloads === 1, r.data.file.downloads);

    // reviews
    check('Free cannot review', (await free.call('POST', `/api/files/${target}/reviews`, { json: { rating: 5, body: 'nice' } })).status === 403);
    check('cannot review own file', (await basic.call('POST', `/api/files/${target}/reviews`, { json: { rating: 5, body: 'mine' } })).status === 400);
    check('Premium can review', (await premium.call('POST', `/api/files/${target}/reviews`, { json: { rating: 4, body: 'works' } })).status === 200);
    check('bad rating rejected', (await premium.call('POST', `/api/files/${target}/reviews`, { json: { rating: 9 } })).status === 400);
    await premium.call('POST', `/api/files/${target}/reviews`, { json: { rating: 5, body: 'even better' } });
    r = await anon.call('GET', '/api/files/' + target);
    check('one review per member, rating updated', r.data.reviews.length === 1 && r.data.file.rating === 5, r.data.reviews);

    // ---- PREMIUM plan ----
    let allOk = true;
    for (let i = 1; i <= 8; i++) {
      const x = await premium.call('POST', '/api/files', { form: uploadForm({ title: 'Premium file ' + i }) });
      if (x.status !== 200) allOk = false;
    }
    check('Premium uploads are unlimited (8 in a row)', allOk);
    r = await premium.call('GET', '/api/me');
    check('Premium usage has no limit', r.data.usage.limit === null && r.data.usage.used === 8, r.data.usage);
    r = await premium.call('GET', '/api/contact');
    check('Premium sees contact links', r.status === 200 && r.data.links[0].value === 'owner#0001', r.data);
    r = await premium.call('POST', '/api/contact', { json: { subject: 'Need help', body: 'My file will not load' } });
    check('Premium can message the owner', r.status === 200, r.data);
    r = await owner.call('GET', '/api/admin/overview');
    check('owner receives the message', r.data.messages.length === 1 && r.data.messages[0].subject === 'Need help');
    check('owner sees pending files', r.data.pendingFiles.length >= 8);

    // ---- payment request flow ----
    r = await free.call('POST', '/api/upgrade', { json: { plan: 'basic', reference: 'TXN12345', note: 'bKash' } });
    check('Free sends upgrade request', r.status === 200, r.data);
    check('second pending request blocked', (await free.call('POST', '/api/upgrade', { json: { plan: 'premium', reference: 'TXN2' } })).status === 409);
    check('bad plan rejected', (await basic.call('POST', '/api/upgrade', { json: { plan: 'god', reference: 'TXN3' } })).status === 400);
    r = await owner.call('GET', '/api/admin/overview');
    const req = r.data.upgrades[0];
    check('owner sees request', req && req.reference === 'TXN12345');
    check('owner activates', (await owner.call('POST', '/api/admin/upgrades/' + req.id, { json: { action: 'approve' } })).status === 200);
    r = await free.call('GET', '/api/me');
    const days = Math.round((r.data.user.planExpires - Date.now()) / 86400000);
    check('Free user is now Basic for ~30 days', r.data.user.plan === 'basic' && days >= 29 && days <= 30, r.data.user);
    r = await free.call('POST', '/api/files', { form: uploadForm({ title: 'Now allowed' }) });
    check('upgraded user can upload', r.status === 200, r.data);

    // ---- expiry ----
    const sql = new DatabaseSync(path.join(dataDir, 'premiumwds.db'));
    sql.prepare("UPDATE users SET plan_expires = ? WHERE email = 'premium@example.com'").run(Date.now() - 1000);
    sql.close();
    r = await premium.call('GET', '/api/me');
    check('expired plan falls back to Free', r.data.user.plan === 'free', r.data.user);
    r = await premium.call('POST', '/api/files', { form: uploadForm() });
    check('expired Premium cannot upload', r.status === 403, r.data);
    check('expired Premium cannot contact', (await premium.call('POST', '/api/contact', { json: { subject: 'Hello', body: 'Hello again' } })).status === 403);

    // ---- logout ----
    await free.call('POST', '/api/logout', { json: {} });
    r = await free.call('GET', '/api/me');
    check('logout works', r.data.user === null);
  } finally {
    server.kill();
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
