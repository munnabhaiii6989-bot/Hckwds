# premiumWds

A file-sharing site with three plans. No npm packages to install: it only needs **Node.js 22.13 or newer**.

| Plan | Price | Can do |
|---|---|---|
| Free | $0 | Browse and download approved files |
| Basic | $1.22 / month | Upload **5 files per month**, write reviews |
| Premium | $4.99 / month (change in `config.js` or `PREMIUM_PRICE`) | **Unlimited uploads**, reviews, **direct contact with you** (message box + your Discord / Telegram / WhatsApp / email links) |

The limits are enforced on the server, so they cannot be bypassed from the browser.
The 5-file limit counts uploads per calendar month (UTC). Deleting a file does not give the slot back.

## Run it

```bash
ADMIN_EMAIL=you@example.com \
PAYMENT_INFO="Send \$1.22 (Basic) or \$4.99 (Premium) to bKash 01XXXXXXXXX, then paste the transaction ID." \
CONTACT_DISCORD="yourname" CONTACT_TELEGRAM="@yourname" \
node server.js
```

Open http://localhost:3000, then **register with the same email as `ADMIN_EMAIL`**. That account becomes the owner and gets an **Owner** page. Owners can always upload and are never limited.

Settings (environment variables): `PORT`, `ADMIN_EMAIL`, `PAYMENT_INFO`, `PREMIUM_PRICE`, `CONTACT_DISCORD`, `CONTACT_TELEGRAM`, `CONTACT_WHATSAPP`, `CONTACT_EMAIL`, `MAX_UPLOAD_MB` (default 25), `DATA_DIR` (where the database and files live), `COOKIE_SECURE=1` (set this on https), `TRUST_PROXY=1` (when behind a host's proxy).

## How members pay (no payment gateway needed)

1. Member opens **Plans**, picks Basic or Premium, sees your `PAYMENT_INFO`, pays you (bKash, PayPal, crypto, anything).
2. Member sends their transaction ID from the site.
3. You open **Owner**, check your payment, press **Payment received, activate**. The plan lasts 30 days. Members renew the same way.

When a plan runs out the account drops back to Free automatically.

Later you can add an automatic gateway. Stripe does not serve Bangladesh-based businesses, so look at options such as Paddle or Lemon Squeezy (check what they support for you). A gateway only needs to call the same "activate plan" step when a payment succeeds.

## Uploads and safety

- Allowed types: `.jar .zip .mcpack .mcaddon .litemod .7z .json .txt .md`. Archives must really be zip files. Max 25 MB.
- Every member upload is **held for your review**. Use **Download to inspect** in the Owner page before pressing Approve. Cheat files are a common way to spread malware, so scan them (for example with VirusTotal) before approving.
- Files are stored under random names and always sent as downloads, never opened in the browser.
- Members must tick a box saying they have the right to share the file and that it has no malware.
- Downloading needs a login.

## Hosting

You need a host that runs Node and keeps a disk between restarts, because the database and uploaded files live in `DATA_DIR`. A small VPS works, or a host with a persistent volume (Railway, Fly.io, Render with a disk). Put it behind https and set `COOKIE_SECURE=1`. Back up `DATA_DIR`.

## Check it works

```bash
npm test
```

Runs 70+ checks: the 5-per-month cap, unlimited Premium, contact locked to Premium, plan expiry, file rules, and more.
