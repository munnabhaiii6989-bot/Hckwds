'use strict';
// premiumWds front end. Plain JavaScript, no build step.
// Everything is built with DOM nodes (textContent), never innerHTML, so user text cannot inject code.

const app = document.getElementById('app');
const nav = document.getElementById('nav');
const S = { cfg: null, me: { user: null }, flash: null };
let renderId = 0;

// ---------- small helpers ----------
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (k === 'style') el.style.cssText = v; // set through CSSOM so the site's CSP allows it
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

async function api(path, { method = 'GET', body, form } = {}) {
  const opts = { method, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  if (form) opts.body = form;
  let res;
  try {
    res = await fetch('/api' + path, opts);
  } catch {
    throw new Error('Cannot reach the server. Check your connection.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Something went wrong.'), { status: res.status });
  return data;
}

const fmtSize = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
const fmtDate = (ms) => new Date(ms).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const money = (p) => '$' + (p === 0 ? '0' : Number(p).toFixed(2));
const stars = (r) => '★'.repeat(Math.round(r || 0)) + '☆'.repeat(5 - Math.round(r || 0));
const notice = (msg, type = '') => h('div', { class: 'notice ' + type, role: type === 'error' ? 'alert' : 'status' }, msg);

function go(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}
function flash(msg, type = 'ok') {
  S.flash = { msg, type };
}
async function loadMe() {
  S.me = await api('/me');
}
const me = () => S.me.user;
const myPlan = () => (S.me.plan ? S.me.plan : S.cfg.plans[0]);

function needLogin(text) {
  return h(
    'div',
    { class: 'card form stack' },
    h('h2', {}, 'Please log in'),
    h('p', { class: 'muted' }, text),
    h('div', { class: 'row' }, h('a', { class: 'btn', href: '#/login' }, 'Log in'), h('a', { class: 'btn secondary', href: '#/register' }, 'Create account')),
  );
}

function field(label, input, hint) {
  const id = 'f' + Math.random().toString(36).slice(2, 8);
  input.id = id;
  return h('div', { class: 'field' }, h('label', { for: id }, label), input, hint && h('div', { class: 'muted small' }, hint));
}

// Runs an action, shows errors inside `box`, and disables the button meanwhile.
async function submitWith(btn, box, fn) {
  box.replaceChildren();
  btn.disabled = true;
  try {
    await fn();
  } catch (e) {
    box.replaceChildren(notice(e.message, 'error'));
    btn.disabled = false;
  }
}

// ---------- views ----------
function fileCard(f) {
  return h(
    'a',
    { class: 'card file-card', href: '#/file/' + f.id },
    h('div', { class: 'row' }, h('span', { class: 'chip' }, f.category), f.mc_version && h('span', { class: 'chip' }, 'MC ' + f.mc_version)),
    h('h3', {}, f.title),
    f.description && h('p', {}, f.description),
    h('div', { class: 'meta' }, h('span', {}, 'by ' + f.author), h('span', {}, fmtSize(f.size)), h('span', {}, f.downloads + ' downloads')),
    f.review_count
      ? h('div', { class: 'meta' }, h('span', { class: 'stars' }, stars(f.rating)), h('span', {}, f.rating.toFixed(1) + ' (' + f.review_count + ')'))
      : h('div', { class: 'meta' }, 'No reviews yet'),
  );
}

async function home() {
  const list = h('div', { class: 'grid' });
  const q = h('input', { type: 'search', placeholder: 'Search files or Minecraft version', 'aria-label': 'Search files' });
  const cat = h('select', { 'aria-label': 'Category' }, h('option', { value: '' }, 'All categories'), S.cfg.categories.map((c) => h('option', { value: c }, c)));
  async function load() {
    const p = new URLSearchParams();
    if (q.value.trim()) p.set('q', q.value.trim());
    if (cat.value) p.set('category', cat.value);
    try {
      const { files } = await api('/files?' + p);
      list.replaceChildren(...(files.length ? files.map(fileCard) : [h('div', { class: 'empty' }, 'No files found yet.')]));
    } catch (e) {
      list.replaceChildren(notice(e.message, 'error'));
    }
  }
  let t;
  q.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(load, 250);
  });
  cat.addEventListener('change', load);
  load();
  return h(
    'div',
    {},
    h(
      'section',
      { class: 'hero' },
      h('h1', {}, 'Minecraft hack files, shared by members.'),
      h('p', {}, 'Browse the library for free. Subscribe to upload your own files, leave reviews, and get direct contact with the owner.'),
      h('div', { class: 'cta' }, h('a', { class: 'btn', href: '#/pricing' }, 'See plans'), !me() && h('a', { class: 'btn secondary', href: '#/register' }, 'Create free account')),
    ),
    h('div', { class: 'filters' }, q, cat),
    list,
  );
}

function planFeatures(p) {
  return [
    [true, 'Browse and download approved files'],
    [p.uploadsPerMonth !== 0, p.uploadsPerMonth === null ? 'Unlimited file uploads' : p.uploadsPerMonth ? `Upload up to ${p.uploadsPerMonth} files per month` : 'Upload your own files'],
    [p.canReview, 'Write reviews'],
    [p.canContact, 'Easy direct contact with the owner'],
  ];
}

async function pricing() {
  const current = me() ? myPlan().id : null;
  return h(
    'div',
    {},
    h('h1', {}, 'Plans'),
    h('p', { class: 'muted' }, 'Pick what fits. Paid plans last ' + S.cfg.planDays + ' days and you can renew any time.'),
    h(
      'div',
      { class: 'plans' },
      S.cfg.plans.map((p) => {
        let cta;
        if (p.id === current) cta = h('button', { class: 'btn secondary', disabled: true }, 'Your current plan');
        else if (p.id === 'free') cta = me() ? null : h('a', { class: 'btn secondary', href: '#/register' }, 'Start free');
        else cta = h('a', { class: 'btn' + (p.id === 'premium' ? ' gold' : ''), href: me() ? '#/upgrade/' + p.id : '#/register' }, 'Get ' + p.name);
        return h(
          'div',
          { class: 'card plan' + (p.id === 'premium' ? ' featured' : '') },
          h('h2', {}, p.name),
          h('div', { class: 'price' }, money(p.price), p.price ? h('small', {}, ' / month') : null),
          h('ul', {}, planFeatures(p).map(([ok, label]) => h('li', { class: ok ? '' : 'no' }, label))),
          cta,
        );
      }),
    ),
  );
}

function authView(kind) {
  const isReg = kind === 'register';
  const box = h('div');
  const name = h('input', { type: 'text', autocomplete: 'name', required: true, maxlength: 40 });
  const email = h('input', { type: 'email', autocomplete: 'email', required: true });
  const pass = h('input', { type: 'password', autocomplete: isReg ? 'new-password' : 'current-password', required: true, minlength: isReg ? 8 : null });
  const btn = h('button', { class: 'btn', type: 'submit' }, isReg ? 'Create account' : 'Log in');
  const form = h(
    'form',
    { class: 'card form', onsubmit: (e) => {
      e.preventDefault();
      submitWith(btn, box, async () => {
        const body = isReg ? { name: name.value, email: email.value, password: pass.value } : { email: email.value, password: pass.value };
        await api(isReg ? '/register' : '/login', { method: 'POST', body });
        await loadMe();
        go('#/');
      });
    } },
    h('h2', {}, isReg ? 'Create your account' : 'Log in'),
    box,
    isReg && field('Name', name),
    field('Email', email),
    field('Password', pass, isReg ? 'At least 8 characters.' : null),
    btn,
    h('p', { class: 'muted small', style: 'margin-top:1rem' }, isReg ? ['Already have an account? ', h('a', { href: '#/login' }, 'Log in')] : ['New here? ', h('a', { href: '#/register' }, 'Create an account')]),
  );
  return form;
}

async function upgradeView(planId) {
  if (!me()) return needLogin('Log in or create an account to get a plan.');
  const plan = S.cfg.plans.find((p) => p.id === planId);
  const pending = (S.me.upgrades || []).find((u) => u.status === 'pending');
  const box = h('div');
  const ref = h('input', { type: 'text', required: true, maxlength: 120, placeholder: 'Transaction ID or payer name' });
  const note = h('textarea', { maxlength: 500, placeholder: 'Optional note' });
  const btn = h('button', { class: 'btn', type: 'submit' }, 'I have paid, send request');
  return h(
    'div',
    { class: 'stack form' },
    h('h1', {}, 'Get ' + plan.name),
    h('div', { class: 'card stack' },
      h('div', { class: 'price', style: 'font-size:1.8rem;font-weight:800' }, money(plan.price), ' ', h('span', { class: 'muted small' }, 'for ' + S.cfg.planDays + ' days')),
      h('h3', {}, '1. Send the payment'),
      h('div', { class: 'pre' }, S.cfg.paymentInfo),
    ),
    pending
      ? notice('You already sent a request. The owner will activate your plan after confirming the payment.', 'warn')
      : h('form', { class: 'card', onsubmit: (e) => {
          e.preventDefault();
          submitWith(btn, box, async () => {
            await api('/upgrade', { method: 'POST', body: { plan: planId, reference: ref.value, note: note.value } });
            await loadMe();
            flash('Request sent. Your plan is activated once the owner confirms the payment.');
            go('#/account');
          });
        } },
        h('h3', {}, '2. Tell us how you paid'),
        box,
        field('Payment reference', ref, 'For example the transaction ID.'),
        field('Note', note),
        btn,
      ),
  );
}

async function uploadView() {
  if (!me()) return needLogin('You need an account to upload files.');
  const plan = myPlan();
  if (plan.uploadsPerMonth === 0) {
    return h('div', { class: 'card form stack' },
      h('h2', {}, 'Uploading is for subscribers'),
      h('p', { class: 'muted' }, 'The Free plan can browse and download. Get Basic to upload up to ' + (S.cfg.plans.find((p) => p.id === 'basic').uploadsPerMonth) + ' files a month, or Premium for unlimited uploads.'),
      h('a', { class: 'btn', href: '#/pricing' }, 'See plans'),
    );
  }
  const { used, limit } = S.me.usage;
  const left = limit === null ? null : Math.max(0, limit - used);
  const box = h('div');
  const title = h('input', { type: 'text', required: true, minlength: 3, maxlength: 80 });
  const cat = h('select', { required: true }, S.cfg.categories.map((c) => h('option', { value: c }, c)));
  const ver = h('input', { type: 'text', maxlength: 20, placeholder: 'e.g. 1.8.9 or 1.21' });
  const desc = h('textarea', { maxlength: 2000, placeholder: 'What does it do? How do you install it?' });
  const file = h('input', { type: 'file', required: true, accept: S.cfg.allowedExt.join(',') });
  const agree = h('input', { type: 'checkbox', required: true });
  const btn = h('button', { class: 'btn', type: 'submit', disabled: left === 0 }, 'Upload file');
  return h('div', { class: 'stack' },
    h('h1', {}, 'Upload a file'),
    h('div', { class: 'card form' },
      limit === null
        ? h('div', {}, h('strong', {}, 'Unlimited uploads'), ' on your Premium plan.')
        : h('div', {}, h('strong', {}, `${used} of ${limit}`), ' uploads used this month.',
            h('div', { class: 'meter' }, h('div', { style: `width:${Math.min(100, (used / limit) * 100)}%` })),
            left === 0 ? h('span', { class: 'muted small' }, 'Limit reached. It resets next month, or upgrade to Premium for unlimited uploads.') : null),
    ),
    h('form', { class: 'card form', onsubmit: (e) => {
        e.preventDefault();
        submitWith(btn, box, async () => {
          const fd = new FormData();
          fd.append('title', title.value);
          fd.append('category', cat.value);
          fd.append('mc_version', ver.value);
          fd.append('description', desc.value);
          fd.append('agree', agree.checked ? 'yes' : 'no');
          fd.append('file', file.files[0]);
          const r = await api('/files', { method: 'POST', form: fd });
          await loadMe();
          flash(r.status === 'approved' ? 'Uploaded and published.' : 'Uploaded. It will appear in the library after the owner reviews it.');
          go('#/account');
        });
      } },
      box,
      field('Title', title),
      field('Category', cat),
      field('Minecraft version', ver),
      field('Description', desc),
      field('File', file, `Max ${S.cfg.maxUploadMB} MB. Allowed: ${S.cfg.allowedExt.join(' ')}`),
      h('label', { class: 'check' }, agree, 'I made this file or have the right to share it, and it contains no malware or stolen code.'),
      h('div', { style: 'margin-top:1rem' }, btn),
    ),
  );
}

async function fileView(id) {
  const { file: f, reviews } = await api('/files/' + id);
  const user = me();
  const plan = user ? myPlan() : null;
  const stateChip = f.status === 'approved' ? null : h('span', { class: 'chip ' + (f.status === 'pending' ? 'warn' : 'bad') }, f.status === 'pending' ? 'Waiting for review' : 'Rejected');
  const own = user && user.id === f.user_id;
  const canDelete = user && (own || user.isAdmin);

  // review form
  let reviewBox;
  if (f.status !== 'approved') reviewBox = null;
  else if (!user) reviewBox = h('p', { class: 'muted' }, h('a', { href: '#/login' }, 'Log in'), ' to download this file.');
  else if (own) reviewBox = h('p', { class: 'muted small' }, 'You cannot review your own file.');
  else if (!plan.canReview) reviewBox = h('div', { class: 'notice' }, 'Reviews are for Basic and Premium members. ', h('a', { href: '#/pricing' }, 'See plans'));
  else {
    let rating = 0;
    const box = h('div');
    const body = h('textarea', { maxlength: 1000, placeholder: 'What worked? Any problems?' });
    const btn = h('button', { class: 'btn', type: 'submit' }, 'Post review');
    const starBtns = [1, 2, 3, 4, 5].map((n) => h('button', { type: 'button', 'aria-label': n + ' stars', onclick: () => {
      rating = n;
      starBtns.forEach((b, i) => b.classList.toggle('on', i < n));
    } }, '★'));
    reviewBox = h('form', { class: 'card stack', onsubmit: (e) => {
        e.preventDefault();
        submitWith(btn, box, async () => {
          await api('/files/' + f.id + '/reviews', { method: 'POST', body: { rating, body: body.value } });
          flash('Review saved.');
          render();
        });
      } },
      h('h3', {}, 'Write a review'), box, h('div', { class: 'star-input' }, starBtns), body, btn);
  }

  return h('div', { class: 'stack' },
    h('div', { class: 'card stack' },
      h('div', { class: 'row' }, h('span', { class: 'chip' }, f.category), f.mc_version && h('span', { class: 'chip' }, 'MC ' + f.mc_version), stateChip),
      h('h1', {}, f.title),
      h('div', { class: 'meta' }, h('span', {}, 'by ' + f.author), h('span', {}, fmtDate(f.created_at)), h('span', {}, fmtSize(f.size)), h('span', {}, f.downloads + ' downloads')),
      f.review_count ? h('div', {}, h('span', { class: 'stars' }, stars(f.rating)), ' ' + f.rating.toFixed(1) + ' (' + f.review_count + (f.review_count === 1 ? ' review)' : ' reviews)')) : h('div', { class: 'muted' }, 'No reviews yet'),
      f.description && h('div', { class: 'pre' }, f.description),
      h('div', { class: 'row' },
        user ? h('a', { class: 'btn', href: '/api/files/' + f.id + '/download' }, 'Download ' + f.orig_name) : h('a', { class: 'btn', href: '#/login' }, 'Log in to download'),
        canDelete && h('button', { class: 'btn danger', onclick: async () => {
          if (!confirm('Delete this file for good?')) return;
          try { await api('/files/' + f.id, { method: 'DELETE' }); flash('File deleted.'); go(own ? '#/account' : '#/'); } catch (e) { alert(e.message); }
        } }, 'Delete'),
      ),
    ),
    reviewBox,
    h('div', { class: 'card' },
      h('h2', {}, 'Reviews'),
      reviews.length ? reviews.map((r) => h('div', { class: 'review' },
        h('div', { class: 'row between' }, h('div', {}, h('strong', {}, r.author), ' ', h('span', { class: 'stars' }, stars(r.rating))), h('span', { class: 'muted small' }, fmtDate(r.created_at))),
        r.body && h('div', { class: 'pre' }, r.body),
        user && (user.id === r.user_id || user.isAdmin) && h('button', { class: 'btn danger small', onclick: async () => { try { await api('/reviews/' + r.id, { method: 'DELETE' }); render(); } catch (e) { alert(e.message); } } }, 'Delete'),
      )) : h('p', { class: 'muted' }, 'Nothing here yet.'),
    ),
  );
}

async function accountView() {
  if (!me()) return needLogin('Log in to see your account.');
  const u = me();
  const plan = myPlan();
  const { files } = await api('/my/files');
  const { used, limit } = S.me.usage;
  return h('div', { class: 'stack' },
    h('h1', {}, 'My account'),
    h('div', { class: 'card stack' },
      h('div', {}, h('strong', {}, u.name), h('div', { class: 'muted' }, u.email)),
      h('div', {}, 'Plan: ', h('span', { class: 'chip ' + (plan.id === 'free' ? '' : 'ok') }, plan.name), u.planExpires ? h('span', { class: 'muted small' }, '  renews or ends ' + fmtDate(u.planExpires)) : null),
      limit === null ? h('div', {}, 'Uploads this month: ' + used + ' (unlimited)')
        : limit === 0 ? h('div', { class: 'muted' }, 'Your plan cannot upload files.')
        : h('div', {}, `Uploads this month: ${used} of ${limit}`, h('div', { class: 'meter' }, h('div', { style: `width:${Math.min(100, (used / limit) * 100)}%` }))),
      plan.id !== 'premium' && h('div', {}, h('a', { class: 'btn', href: '#/pricing' }, plan.id === 'free' ? 'Upgrade' : 'Go Premium')),
    ),
    (S.me.upgrades || []).length ? h('div', { class: 'card' }, h('h3', {}, 'Payment requests'),
      S.me.upgrades.map((q) => h('div', { class: 'review row between' }, h('span', {}, q.plan + ' · ' + q.reference), h('span', { class: 'chip ' + (q.status === 'approved' ? 'ok' : q.status === 'pending' ? 'warn' : 'bad') }, q.status)))) : null,
    h('div', { class: 'card' },
      h('div', { class: 'row between' }, h('h3', {}, 'My uploads'), plan.uploadsPerMonth !== 0 && h('a', { class: 'btn small', href: '#/upload' }, 'Upload')),
      files.length ? files.map((f) => h('div', { class: 'review row between' },
        h('a', { href: '#/file/' + f.id }, f.title),
        h('span', { class: 'chip ' + (f.status === 'approved' ? 'ok' : f.status === 'pending' ? 'warn' : 'bad') }, f.status === 'pending' ? 'waiting for review' : f.status))) : h('p', { class: 'muted' }, 'No uploads yet.'),
    ),
  );
}

async function contactView() {
  if (!me()) return needLogin('Log in to contact the owner.');
  if (!myPlan().canContact) {
    return h('div', { class: 'card form stack' },
      h('h2', {}, 'Direct contact is a Premium feature'),
      h('p', { class: 'muted' }, 'Premium members can message the owner straight from the site and get the owner’s chat links.'),
      h('a', { class: 'btn gold', href: '#/upgrade/premium' }, 'Get Premium'),
    );
  }
  const { links } = await api('/contact');
  const box = h('div');
  const subject = h('input', { type: 'text', required: true, minlength: 3, maxlength: 100 });
  const body = h('textarea', { required: true, minlength: 5, maxlength: 2000 });
  const btn = h('button', { class: 'btn', type: 'submit' }, 'Send message');
  return h('div', { class: 'stack' },
    h('h1', {}, 'Contact the owner'),
    links.length ? h('div', { class: 'card' }, h('h3', {}, 'Direct links'), links.map((l) => h('div', {}, h('strong', {}, l.label + ': '), h('span', { class: 'pre' }, l.value)))) : null,
    h('form', { class: 'card form', onsubmit: (e) => {
        e.preventDefault();
        submitWith(btn, box, async () => {
          await api('/contact', { method: 'POST', body: { subject: subject.value, body: body.value } });
          flash('Message sent. The owner will get back to you.');
          render();
        });
      } },
      h('h3', {}, 'Send a message'), box, field('Subject', subject), field('Message', body), btn),
  );
}

async function adminView() {
  if (!me() || !me().isAdmin) return needLogin('This page is for the site owner.');
  const d = await api('/admin/overview');
  const act = (path, body) => async () => {
    try { await api(path, { method: 'POST', body }); render(); } catch (e) { alert(e.message); }
  };
  const section = (title, items, empty) => h('div', { class: 'card' }, h('h3', {}, title + ' (' + items.length + ')'), items.length ? items : h('p', { class: 'muted' }, empty));
  return h('div', { class: 'stack' },
    h('h1', {}, 'Owner panel'),
    h('div', { class: 'meta' }, h('span', {}, d.stats.users + (d.stats.users === 1 ? ' member' : ' members')), h('span', {}, d.stats.files + (d.stats.files === 1 ? ' published file' : ' published files'))),
    section('Files waiting for review', d.pendingFiles.map((f) => h('div', { class: 'review stack' },
      h('div', {}, h('a', { href: '#/file/' + f.id }, f.title), h('span', { class: 'muted small' }, '  by ' + f.author + ' · ' + f.orig_name + ' · ' + fmtSize(f.size))),
      h('div', { class: 'row' },
        h('a', { class: 'btn secondary small', href: '/api/files/' + f.id + '/download' }, 'Download to inspect'),
        h('button', { class: 'btn small', onclick: act('/admin/files/' + f.id + '/status', { status: 'approved' }) }, 'Approve'),
        h('button', { class: 'btn danger small', onclick: act('/admin/files/' + f.id + '/status', { status: 'rejected' }) }, 'Reject')),
    )), 'Nothing to review.'),
    section('Payment requests', d.upgrades.map((q) => h('div', { class: 'review stack' },
      h('div', {}, h('strong', {}, q.name), ' (' + q.email + ') wants ', h('strong', {}, q.plan)),
      h('div', { class: 'muted small pre' }, 'Reference: ' + q.reference + (q.note ? '\n' + q.note : '')),
      h('div', { class: 'row' },
        h('button', { class: 'btn small', onclick: act('/admin/upgrades/' + q.id, { action: 'approve' }) }, 'Payment received, activate'),
        h('button', { class: 'btn danger small', onclick: act('/admin/upgrades/' + q.id, { action: 'reject' }) }, 'Reject')),
    )), 'No payment requests.'),
    section('Messages from Premium members', d.messages.map((m) => h('div', { class: 'review stack' },
      h('div', {}, h('strong', {}, m.subject), h('span', { class: 'muted small' }, '  ' + m.name + ' (' + m.email + ') · ' + fmtDate(m.created_at))),
      h('div', { class: 'pre' }, m.body),
      h('div', {}, h('button', { class: 'btn secondary small', onclick: act('/admin/messages/' + m.id + '/done') }, 'Mark done')),
    )), 'No open messages.'),
    h('div', { class: 'card' }, h('h3', {}, 'Members'),
      h('div', { class: 'table-wrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Name', 'Plan', 'Set plan'].map((t) => h('th', {}, t)))),
        h('tbody', {}, d.users.map((u) => {
          const sel = h('select', {}, S.cfg.plans.map((p) => h('option', { value: p.id, selected: p.id === u.plan }, p.name)));
          const days = h('input', { type: 'number', min: 1, max: 3650, value: S.cfg.planDays, 'aria-label': 'Days', style: 'width:5.5rem' });
          const expired = u.plan !== 'free' && u.plan_expires && u.plan_expires < Date.now();
          return h('tr', {},
            h('td', {}, u.name, h('div', { class: 'muted small' }, u.email), u.is_admin ? h('span', { class: 'chip' }, 'owner') : null),
            h('td', {}, u.plan + (expired ? ' (expired)' : ''), u.plan_expires && u.plan !== 'free' ? h('div', { class: 'muted small' }, 'until ' + fmtDate(u.plan_expires)) : null),
            h('td', {}, h('div', { class: 'row' }, sel, days, h('button', { class: 'btn small', onclick: () => act('/admin/users/' + u.id + '/plan', { plan: sel.value, days: days.value })() }, 'Set'))));
        })),
      )),
    ),
  );
}

// ---------- shell ----------
const routes = [
  [/^#\/?$/, home],
  [/^#\/pricing$/, pricing],
  [/^#\/login$/, () => authView('login')],
  [/^#\/register$/, () => authView('register')],
  [/^#\/upgrade\/(basic|premium)$/, upgradeView],
  [/^#\/upload$/, uploadView],
  [/^#\/file\/(\d+)$/, fileView],
  [/^#\/account$/, accountView],
  [/^#\/contact$/, contactView],
  [/^#\/admin$/, adminView],
];

function renderNav() {
  const here = location.hash || '#/';
  const link = (href, label) => h('a', { href, class: here === href ? 'active' : null }, label);
  const u = me();
  const items = [
    link('#/', 'Browse'),
    link('#/pricing', 'Plans'),
    ...(u
      ? [
          link('#/upload', 'Upload'),
          link('#/contact', 'Contact'),
          u.isAdmin ? link('#/admin', 'Owner') : null,
          link('#/account', u.name.split(' ')[0]),
          h('button', { onclick: async () => { try { await api('/logout', { method: 'POST' }); } catch { /* ignore */ } await loadMe().catch(() => {}); go('#/'); } }, 'Log out'),
        ]
      : [link('#/login', 'Log in'), h('a', { class: 'btn small', href: '#/register' }, 'Sign up')]),
  ];
  nav.replaceChildren(...items.filter(Boolean));
}

async function render() {
  const mine = ++renderId;
  const hash = location.hash || '#/';
  let view = null;
  for (const [re, fn] of routes) {
    const m = re.exec(hash);
    if (m) { view = () => fn(...m.slice(1)); break; }
  }
  renderNav();
  let node;
  try {
    node = view ? await view() : notice('Page not found.', 'error');
  } catch (e) {
    if (e.status === 401) { await loadMe().catch(() => {}); renderNav(); node = needLogin('Please log in to continue.'); }
    else node = notice(e.message, 'error');
  }
  if (mine !== renderId) return;
  const kids = [];
  if (S.flash) { kids.push(notice(S.flash.msg, S.flash.type)); S.flash = null; }
  kids.push(node);
  app.replaceChildren(...kids);
  window.scrollTo(0, 0);
}

async function start() {
  try {
    S.cfg = await api('/config');
    await loadMe();
    document.title = S.cfg.siteName;
  } catch (e) {
    app.replaceChildren(notice(e.message, 'error'));
    return;
  }
  window.addEventListener('hashchange', render);
  render();
}
start();
